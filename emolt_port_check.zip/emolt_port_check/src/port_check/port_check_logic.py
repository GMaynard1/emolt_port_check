import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
import pyproj


def out_of_port_check(lat, lon):
    ## Create an empty dataframe to store the point(s) of interest
    p = pd.DataFrame({
        'LATITUDE': pd.Series(dtype='float'),
        'LONGITUDE': pd.Series(dtype='float')
    })

    ## Fill in the point(s) of interest
    p.loc[1] = [lat, lon]

    ## Convert the dataframe to a geodataframe called 'points'
    points = gpd.GeoDataFrame(p, geometry=[Point(xy) for xy in zip(p["LONGITUDE"], p["LATITUDE"])])

    ## Read in the shapefile of ports
    ports = gpd.read_file("../../data/emolt_ports/emolt_ports.shp")

    ## Assign a coordinate reference system to both the points and the ports
    points.crs = pyproj.CRS("+proj=longlat +datum=WGS84 +no_defs")
    ports.crs = pyproj.CRS("+proj=longlat +datum=WGS84 +no_defs")

    ## Results is a vector of either NaN or Port Names depending on whether the point is within a port or not
    results = points.sjoin(ports, how="left", predicate="intersects")['PORT_NAME']

    ## Return a True / False value to show if the point is out of port (True) or in port (False)
    return results.isna()


print(out_of_port_check(35, -75))
